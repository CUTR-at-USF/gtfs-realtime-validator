Testing whether the GTFS data is successfully loading into memory or not. 
If we provide this bad GTFS zip file whose file names doen not macth the actual file names and the data in them is not correctly formatted,
 the application should fail on saving the GTFS data to memory.